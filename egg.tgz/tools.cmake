# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(honggfuzz src/honggfuzz.cpp)
set_property(TARGET honggfuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(honggfuzz lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(windows-x86 src/windows-x86.cpp)
set_property(TARGET windows-x86 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x86 lionss pthread)

add_executable(draft-release src/draft-release.cpp)
set_property(TARGET draft-release PROPERTY CXX_STANDARD 11)
target_link_libraries(draft-release lionss pthread)

add_executable(badge-check src/badge-check.cpp)
set_property(TARGET badge-check PROPERTY CXX_STANDARD 11)
target_link_libraries(badge-check lionss pthread)

add_executable(microbench src/microbench.cpp)
set_property(TARGET microbench PROPERTY CXX_STANDARD 11)
target_link_libraries(microbench lionss pthread)

add_executable(jetson-build src/jetson-build.cpp)
set_property(TARGET jetson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jetson-build lionss pthread)

add_executable(wheel-build src/wheel-build.cpp)
set_property(TARGET wheel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wheel-build lionss pthread)

add_executable(nvcc-build src/nvcc-build.cpp)
set_property(TARGET nvcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nvcc-build lionss pthread)

add_executable(watchos-build src/watchos-build.cpp)
set_property(TARGET watchos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(watchos-build lionss pthread)

add_executable(boundary-tests src/boundary-tests.cpp)
set_property(TARGET boundary-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(boundary-tests lionss pthread)

add_executable(integration-tests src/integration-tests.cpp)
set_property(TARGET integration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(integration-tests lionss pthread)

add_executable(gcc-trunk src/gcc-trunk.cpp)
set_property(TARGET gcc-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-trunk lionss pthread)

add_executable(sast-scan src/sast-scan.cpp)
set_property(TARGET sast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(sast-scan lionss pthread)

add_executable(ccache-stats src/ccache-stats.cpp)
set_property(TARGET ccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(ccache-stats lionss pthread)

add_executable(coverage-diff src/coverage-diff.cpp)
set_property(TARGET coverage-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-diff lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(mkdocs-build src/mkdocs-build.cpp)
set_property(TARGET mkdocs-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mkdocs-build lionss pthread)

add_executable(sccache-stats src/sccache-stats.cpp)
set_property(TARGET sccache-stats PROPERTY CXX_STANDARD 11)
target_link_libraries(sccache-stats lionss pthread)

add_executable(address-sanitizer src/address-sanitizer.cpp)
set_property(TARGET address-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(address-sanitizer lionss pthread)

add_executable(leak-sanitizer src/leak-sanitizer.cpp)
set_property(TARGET leak-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(leak-sanitizer lionss pthread)

add_executable(tsan src/tsan.cpp)
set_property(TARGET tsan PROPERTY CXX_STANDARD 11)
target_link_libraries(tsan lionss pthread)

add_executable(build-header-only src/build-header-only.cpp)
set_property(TARGET build-header-only PROPERTY CXX_STANDARD 11)
target_link_libraries(build-header-only lionss pthread)

add_executable(spdx-sbom src/spdx-sbom.cpp)
set_property(TARGET spdx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(spdx-sbom lionss pthread)

add_executable(retry-matrix src/retry-matrix.cpp)
set_property(TARGET retry-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(retry-matrix lionss pthread)

add_executable(headless-tests src/headless-tests.cpp)
set_property(TARGET headless-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(headless-tests lionss pthread)

add_executable(differential-fuzz src/differential-fuzz.cpp)
set_property(TARGET differential-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(differential-fuzz lionss pthread)

add_executable(gcov-report src/gcov-report.cpp)
set_property(TARGET gcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(gcov-report lionss pthread)

add_executable(chocolatey-package src/chocolatey-package.cpp)
set_property(TARGET chocolatey-package PROPERTY CXX_STANDARD 11)
target_link_libraries(chocolatey-package lionss pthread)

