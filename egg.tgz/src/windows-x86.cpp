// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("windows x86\n", stdout);
  return lionss_run_workload("windows-x86");
}
