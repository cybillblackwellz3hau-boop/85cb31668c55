// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("boundary tests"); }
int main(){
  announce();
  return lionss_run_workload("boundary-tests");
}
